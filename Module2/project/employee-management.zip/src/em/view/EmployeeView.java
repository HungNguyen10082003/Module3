package em.view;

import em.entity.Employee;

import java.util.List;

public class EmployeeView {
    public void printHeader() {
        System.out.println("ID   | Name                 | Email                     | Department   |   Salary");
        System.out.println("-----+----------------------+---------------------------+--------------+----------");
    }

    public void showList(List<Employee> list) {
        printHeader();
        for (Employee e : list) {
            System.out.println(e);
        }
    }

    public void showDetail(Employee e) {
        printHeader();
        System.out.println(e);
    }

    public void showMessage(String msg) { System.out.println(msg); }
}

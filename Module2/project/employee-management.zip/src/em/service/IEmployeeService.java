package em.service;

import em.entity.Employee;
import java.util.List;
import java.util.Optional;

public interface IEmployeeService {
    List<Employee> getAll();
    Optional<Employee> getById(int id);
    Employee create(String name, String email, String department, double salary);
    Employee update(int id, String name, String email, String department, double salary);
    boolean delete(int id);
}
